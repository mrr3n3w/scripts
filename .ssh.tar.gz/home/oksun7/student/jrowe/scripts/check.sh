#!/bin/bash
#check.sh

ls -al /home/oksun7/cosc/akennedy/student/$USER
