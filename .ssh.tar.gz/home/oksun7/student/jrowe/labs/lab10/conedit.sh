#!/bin/bash


if [ -e $1 ] && [ $# == 1 ]; then

  i=0
  echo "Configuration Editor"

  while [ $i -lt 21 ];
  do
      echo -n "="
      let i=i+1
  done
  # I found this to be the easiest way to take out the lines with # and also the blank lines. 
  # However this saves all files temp, temp1 and temp2
  # My program on exit will delete all the files it creates
  cat $1 > temp
  sed /#/d temp > temp1
  cat temp1 > temp
  sed /^$/d temp > temp2
  cat temp2 > $1

  echo
  echo    "Select a choice: "
  echo    "v - View parameteres and settings"
  echo    "e - Edit a parameter"
  echo    "d - Delete a parameter"
  echo    "q - Quit "
  echo

  while [ "$vedq" != "q" ];
    do
      echo
      echo -n "Choice: " 
      read vedq 
      echo 

      case $vedq in

	  [vV]* ) cat $1 2>/dev/null;;

	  [eE]* ) echo -n "What parameter would you like to edit? "; read edit; grep $edit temp;
        if [ $? -ne 0 ]
        then
          echo "Error: No such parameter"
        else
          grep "^$edit=.*" $1 | cut -d '=' -f2 > value; 
	  echo -n "Change current value of $edit (`cat value`) to : "; read valuen; sed s/`cat value`/$valuen/ temp > $1 ; 
          cat temp1 > $1;
          fi;;

      [dD]* ) echo -n "Name of parameter to delete: " ;  read rm;  grep $rm temp;
        if [ $? -ne 0 ]
        then
          echo "Error: No such parameter"
        else
            grep "$rm=" temp > rm ;   
	    sed /`cat rm`/d $1 > temp; cat temp > $1;
        fi;;

      [qQ]* ) break; rm temp temp1 temp2 rm value 2> /dev/null;;
        
        * ) echo "- Invaild Choice";;
     esac
    done

elif [ ! -e $1 ] ; then
  echo "$1 does not exists. Check spelling or path."

elif [ $# -ne 1 ] ; then  
  echo "Usage: You must specify a configuration file to edit."
fi
